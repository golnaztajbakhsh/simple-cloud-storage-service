class ValidationError(Exception):
    pass

class S3OperationError(Exception):
    pass
